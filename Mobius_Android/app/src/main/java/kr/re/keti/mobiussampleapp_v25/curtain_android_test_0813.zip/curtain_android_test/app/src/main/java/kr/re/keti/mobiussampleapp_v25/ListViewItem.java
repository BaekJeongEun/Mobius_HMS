package kr.re.keti.mobiussampleapp_v25;

public class ListViewItem {

    private String titleStr ;

    public void setTitle(String title) {
        titleStr = title ;
    }

    public String getTitle() {
        return this.titleStr ;
    }


    /*

    private String descStr ;
    public void setDesc(String desc) {
        descStr = desc ;
    }

    public String getDesc() {
        return this.descStr ;
    }

    */

}
