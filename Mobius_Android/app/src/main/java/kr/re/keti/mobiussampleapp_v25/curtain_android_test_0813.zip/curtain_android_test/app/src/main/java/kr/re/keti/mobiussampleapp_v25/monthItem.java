package kr.re.keti.mobiussampleapp_v25;

public class monthItem {
    int day;

    public monthItem(int day) {

        this.day = day;
    }

}
