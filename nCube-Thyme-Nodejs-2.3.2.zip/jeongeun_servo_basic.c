 //	마그네틱 센서 감지, 서보모터 구동

// gcc jeongeun_servo_basic.c -o door -lwiringPi
// sudo ./door
 
#include <wiringPi.h>
#include <stdio.h>
#include <softPwm.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define SERVO 1			// jeongeuni
#define SERVO_PIN 0	// taeyeoni
#define MAGNETIC 2

void open_door();
void lock_door();
void open_curtain();
void close_curtain();
void stop_curtain();

int main(int argc,char *argv[])
{
	int i;
    for (i=0; i < argc; i++)
    printf("Argument %d is %s\n", i, argv[i]);
	
	if(wiringPiSetup()==-1) return 1;
	
	pinMode(SERVO, PWM_OUTPUT);
	pinMode(MAGNETIC, INPUT);
	softPwmCreate(SERVO,0,200);
	pinMode(SERVO_PIN, PWM_OUTPUT);
	softPwmCreate(SERVO_PIN,0,200);
	
	
	if(digitalRead(MAGNETIC) == 1)
		printf("문 닫힘!\n");
	else if(digitalRead(MAGNETIC) != 1)
		printf("문 열림!\n");	
	
	if(argc == 2){
		char* comm = argv[1];
		
		if(strcmp(comm, "1") == 0){
			open_door();
		} 
		else if(strcmp(comm, "2") == 0){
			lock_door();
		} 
		else if(strcmp(comm, "3") == 0){		
			open_curtain();
		}
		else if(strcmp(comm, "4") == 0){				
			close_curtain();
		}
		else if(strcmp(comm, "5") == 0){
			stop_curtain();
		}
	}
	
	return 0;
}

void open_door()
{
	softPwmWrite(SERVO,75);				
	delay(600);	
	softPwmWrite(SERVO,5);
	delay(600);
}

void lock_door()
{
	softPwmWrite(SERVO,5);
	delay(600);
	softPwmWrite(SERVO,25);
	delay(600);
}

void open_curtain(){
	printf("%s\n", "curtain open!");
	
	softPwmWrite(SERVO_PIN,24);
	delay(1000);
	softPwmWrite(SERVO_PIN,0);
	/*
	printf("%s\n", "curtain open!");
	softPwmWrite(SERVO_PIN,HIGH);
	delay(1000);
	softPwmWrite(SERVO_PIN,LOW);
	*/
}

void close_curtain(){
	printf("%s\n", "curtain close!");
	softPwmWrite(SERVO_PIN,5);	
	delay(1000);
	softPwmWrite(SERVO_PIN,0);
	/*
	printf("%s\n", "curtain close!");
	softPwmWrite(SERVO_PIN,HIGH);
	delay(3000);
	softPwmWrite(SERVO_PIN,LOW);
	*/
}

void stop_curtain(){
	printf("%s\n", "curtain stop!!! 코드 추가하기!");
	//softPwmWrite(SERVO_PIN,LOW);
}

/*
  //	마그네틱 센서 감지, 서보모터 구동

// gcc jeongeun_servo_basic.c -o JE_servo -lwiringPi
// sudo ./JE_servo
 
#include <wiringPi.h>
#include <stdio.h>
#include <softPwm.h>
#include <stdlib.h>
#include <unistd.h>

#define SERVO 1
#define MAGNETIC 2

int main(int argc,char *argv[])
{
	if(wiringPiSetup()==-1) return 1;
	
	pinMode(SERVO, PWM_OUTPUT);
	pinMode(MAGNETIC, INPUT);
	softPwmCreate(SERVO,0,200);
	
	while(1)
	{
		if(digitalRead(MAGNETIC) == 1)
			printf("문 닫힘!\n");
		else if(digitalRead(MAGNETIC) != 1)
			printf("문 열림!\n");
		
		char str;
		printf("select r, l, q : ");
		scanf("%c",&str);
		if(str == 'r')
		{			
			softPwmWrite(SERVO,75);				
			delay(600);	
			softPwmWrite(SERVO,5);
			delay(600);
		}
		else if(str == 'l')
		{				
			softPwmWrite(SERVO,5);
			delay(600);
			softPwmWrite(SERVO,25);
			delay(600);
		}	
		else if(str == 'q')	return 0;		
	}	
	
	
	return 0;
}

 
 
 */

/*
 
// 스레드 사용, 마그네틱 센서 감지 + 서보모터 구동

// gcc jeongeun_servo_basic.c -o JE_servo -lwiringPi -pthread
// sudo ./JE_servo

#include <wiringPi.h>
#include <stdio.h>
#include <softPwm.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define SERVO 1
#define MAGNETIC 2

void *motor_function(void*);
void *mag_function(void*);

int main()
{
	if(wiringPiSetup()==-1) return 1;
	
	pinMode(SERVO, PWM_OUTPUT);
	pinMode(MAGNETIC, INPUT);
	softPwmCreate(SERVO,0,200);
	
	pthread_t pmotor, pmag;
	
	pthread_create(&pmotor, NULL, motor_function, NULL);
	pthread_create(&pmag, NULL, mag_function, NULL);
	
	pthread_join(pmotor, NULL);
	pthread_join(pmag, NULL);
		
	return 0;
}

void *motor_function(void*arg)
{
	while(1)
	{
		char str;
		printf("select r, l, q : ");
		scanf("%c",&str);
		if(str == 'r')
		{			
			softPwmWrite(SERVO,75);				
			delay(600);	
			softPwmWrite(SERVO,5);
			delay(600);
		}
		else if(str == 'l')
		{				
			softPwmWrite(SERVO,5);
			delay(600);
			softPwmWrite(SERVO,25);
			delay(600);
		}	
		else if(str == 'q')	return 0;
	}
}

void *mag_function(void*arg)
{
	while(1){
		if(digitalRead(MAGNETIC) == 1)
			printf("문 닫힘!\n");
		else if(digitalRead(MAGNETIC) != 1)
			printf("문 열림!\n");
	}
}


*/

/*
int main()
{
	char str;
	if(wiringPiSetup()==-1)
		return 1;
	softPwmCreate(SERVO,0,200);
	
	while(1)
	{
			printf("select r, l, q : ");
			scanf("%c",&str);
			getchar();
			if(str == 'r')
			{
				softPwmWrite(SERVO,24);
				usleep(5000);
				softPwmWrite(SERVO,0);
			}
			else if(str == 'l')
			{
				softPwmWrite(SERVO,5);
				usleep(5000);
				softPwmWrite(SERVO,0);
			}
			else if(str == 'c')
			{
				softPwmWrite(SERVO,15);
				usleep(5000);
				softPwmWrite(SERVO,0);
			}
			else if(str == 'q')	return 0;
	}	
	return 0;
}
*/

/*int main()
{
		if(wiringPiSetupPhys()==-1)
			exit(1);
		pinMode(SERVO, PWM_OUTPUT);
		
		pwmSetMode(PWM_MODE_MS);
		
		pwmWrite(SERVO,PWM_OUTPUT);
		
		pwmSetClock(384);
		pwmSetRange(1000);
		
		pwmWrite(SERVO,30);
		sleep(1);	
		
		pwmWrite(SERVO,120);
		sleep(1);	
		
		pwmWrite(SERVO,75);
		sleep(1);	
		
		float val;
		while(-1){
			printf("(30~75~120) = ");
			scanf("%f",&val);
			
			if(val == -1) break;
			
			pwmWrite(SERVO, val);
			sleep(1);
		}
		return 0;
}

 */

/*int main(int argc, char *argv[])
{
	int pos=180;
	int dir=1;
	if(wiringPiSetup()==-1) exit(1);
	pinMode(0,OUTPUT);
	digitalWrite(0,LOW);
	softPwmCreate(0,0,200);
	while(1)
	{	
		pos+=dir;
		printf("반복문 // ");
		if(pos<180 || pos>194) dir*=-1;
		softPwmWrite(0,pos);
		delay(50);
	}printf("반복문 // ");
	
//	for(; pos<194; pos++)
//	{
//		printf("반복문 // ");
//		softPwmWrite(0,pos);
//		delay(50);
//	}
	
	return 0;
}
*/
