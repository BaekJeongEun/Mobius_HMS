import RPi.GPIO as GPIO
import time
import sys
import threading
import Adafruit_Python_DHT as dht

# Thread names
ledTh= threading.Thread()
fndTh= threading.Thread()
piazzoTh= threading.Thread()
dhtTh= threading.Thread()
ultraTh= threading.Thread()
# Mutex names
ledLock=threading.Lock()
fndLock=threading.Lock()
piazzoLock=threading.Lock()
dhtLock=threading.Lock()
ultraLock=threading.Lock()

# Set up the pin mode
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# LED의 pin 번호
GPIO_LED = 18					#GPIO18
GPIO.setup(GPIO_LED, GPIO.OUT)
# HC-SR04의 트리거 핀을 GPIO20번, 에코핀을 GPIO21번에 연결한다.
GPIO_TRIGGER = 20  				#GPIO20  
GPIO_ECHO = 21   				#GPIO21
GPIO.setup(GPIO_TRIGGER,GPIO.OUT) 
GPIO.setup(GPIO_ECHO,GPIO.IN)
# Piazzo (music) 의 pin번호 및 연주 계명
GPIO_PIAZZO = 25
GPIO.setup(GPIO_PIAZZO, GPIO.OUT)			# Uses GPIO number
# FND 의 pin 번호, 출력모드 설정 및 숫자 배열
gpiopins = [23, 12, 15, 14]
number = [ [0,0,0,0] , [0,0,0,1] , [0,0,1,0] , [0,0,1,1] , [0,1,0,0] , [0,1,0,1] , [0,1,1,0] , [0,1,1,1] , [1,0,0,0] , [1,0,0,1] ]  	# 0~9
clear = [1,1,1,1] 																				# Output to clear	
for i in gpiopins[0:] :
	GPIO.setup(i,GPIO.OUT)
	GPIO.output(i, 1)
# DHT의 pin 번호 설정
GPIO_DHT = 7

def dhtControl() :
	if (not dhtLock.acquire(False)):		# Works like trylock
		return
	try:
		for i in range(10) :			# 10번만 출력				
			h, t = dht.read_retry(dht.DHT11, 7)
			print("Temper = {0:0.1f}*C  Humidity={1:0.1f}%" .format(t,h))
			time.sleep(1)
		dhtLock.release()
	except Exception as msg:
		print("dhtTH ending....", msg)
		# clear the display

def fndControl() :
	global gpiopins, number, clear
	if (not fndLock.acquire(False)):		# Works like trylock
		return
	try :
		# display number 0~9
		for i in range(0,len(number[0:]))  :
			for j in range(0,len(gpiopins[0:])) :
				GPIO.output( gpiopins[j] , number[i][j])
			time.sleep(1)
	except Exception as msg:
		print("piazzoTH ending....", msg)
		# clear the display
		for i in range(0,len(gpiopins[0:])) :
			GPIO.output( gpiopins[i] , clear[i])
	finally:
		# clear the display
		for i in range(0,len(gpiopins[0:])) :
			GPIO.output( gpiopins[i] , clear[i])
		fndLock.release()

def piazzoControl() :
	global GPIO_PIAZZO
	p = GPIO.PWM(GPIO_PIAZZO, 500)
	note = [391,391,440,440,391,391,329.63,329.63,
	391,391,329.63,329.63,293.66,293.66,293.66,10,
	391,391,440,440,391,391,329.63,329.63,
	391,329.63,293.66,329.63,261.63,261.63,261.63,10]
	if (not piazzoLock.acquire(False)):		# Works like trylock
		return
	try :
		time.sleep(0.5)
		for i in note[0:] :
			p.start(99)
			p.ChangeFrequency(i)
			time.sleep(0.5)
			p.stop()
			#time.sleep(0.1)
		piazzoLock.release()
	except Exception as msg:
		print("piazzoTH ending....", msg)

# led를 제어하는 함수
def ledControl() :
	global GPIO_LED, ledLock
	if (not ledLock.acquire(False)):		# Works like trylock
		return
	try:
		for i in range(1,6):
			GPIO.output(GPIO_LED, True)
			time.sleep(1)
			GPIO.output(GPIO_LED, False)
			time.sleep(1)
		ledLock.release()
	except Exception as msg:
		print("ledTH ending....", msg)

def ultraControl() :
	global GPIO_TRIGGER, GPIO_ECHO, ultraLock    
	if (not ultraLock.acquire(False)):		# Works like trylock
		return

	try:
		for i in range(10):					# 10번 만			
			stop = 0
			start = 0
			# 먼저 트리거 핀을 OFF 상태로 유지한다
			GPIO.output(GPIO_TRIGGER, False)
			time.sleep(1)

			# 10us 펄스를 내보낸다. 
			# 파이썬에서 이 펄스는 실제 100us 근처가 될 것이다.
			# 하지만 HC-SR04 센서는 이 오차를 받아준다.
			GPIO.output(GPIO_TRIGGER, True)
			time.sleep(0.00001)
			GPIO.output(GPIO_TRIGGER, False)

			# 에코 핀이 ON되는 시점을 시작 시간으로 잡는다.
			while GPIO.input(GPIO_ECHO)==0:
			    start = time.time()

			# 에코 핀이 다시 OFF되는 시점을 반사파 수신 시간으로 잡는다.
			while GPIO.input(GPIO_ECHO)==1:
			    stop = time.time()

			# Calculate pulse length
			elapsed = stop-start

			# 초음파는 반사파이기 때문에 실제 이동 거리는 2배이다. 따라서 2로 나눈다.
			# 음속은 편의상 340m/s로 계산한다. 현재 온도를 반영해서 보정할 수 있다.
			if (stop and start):
			    distance = (elapsed * 34000.0) / 2
			    print ("Distance : %.1f cm" % distance)
		ultraLock.release()
	except Exception as msg:
		print("ultraTh ending...", msg)

def main():
	global ledTh, ultraTh
	try:
		while True:				#무한 루프
			choice = input("l : LED On/Off, m : Music, f : FND, t : DHT, d : Ultra, q : Quit \n")
			if (choice=='l'):
				print("Light On/Off")
				ledTh = threading.Thread(target=ledControl)
				ledTh.start()
			elif (choice=='d'):
				print("Distance on...")
				ultraTh = threading.Thread(target=ultraControl)
				ultraTh.start()
			elif (choice=='m'):
				print("Music on...")
				piazzoTh = threading.Thread(target=piazzoControl)
				piazzoTh.start()
			elif (choice=='f'):
				print("FND on...")
				fndTh = threading.Thread(target=fndControl)
				fndTh.start()
			elif (choice=='t'):
				print("Temperature and Humidity on...")
				dhtTh = threading.Thread(target=dhtControl)
				dhtTh.start()
			elif (choice=='q'):
				break
			else:
				print("Invalid choice")
	except KeyboardInterrupt:
		print("\n Interrupted!! Goodbye~~")

main()
# Clean-up
GPIO.cleanup()

